import React, { useState } from 'react';
import { Layout } from './components/Layout';
import { Auth } from './components/Auth';
import { Assessment } from './components/Assessment';
import { Dashboard } from './components/Dashboard';
import { RoadmapView } from './components/RoadmapView';
import { Games } from './components/Games';
import { Jobs } from './components/Jobs';
import { FeedbackModal } from './components/FeedbackModal';
import { User, Roadmap, ViewState, UserStats } from './types';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<ViewState>('auth');
  const [roadmap, setRoadmap] = useState<Roadmap | null>(null);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  
  // Stats state (persisted in a real app)
  // FIXED: Initial Streak is now 0.
  const [stats, setStats] = useState<UserStats>({
    xp: 0,
    streak: 0, 
    completedModules: 0,
    currentNsqfLevel: 0
  });

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    // In a real app, check if user has a roadmap
    setCurrentView('assessment'); // Default to assessment for new flow demonstration
  };

  const handleAssessmentComplete = (newRoadmap: Roadmap) => {
    setRoadmap(newRoadmap);
    // Set initial NSQF based on AI assessment
    setStats(prev => ({...prev, currentNsqfLevel: Math.max(1, newRoadmap.targetNsqfLevel - 4)})); 
    setCurrentView('dashboard');
  };

  const toggleRoadmapStep = (stepId: string) => {
    if (!roadmap) return;

    const updatedSteps = roadmap.steps.map(step => {
        if (step.id === stepId) {
            return { ...step, completed: !step.completed };
        }
        return step;
    });

    setRoadmap({ ...roadmap, steps: updatedSteps });
    
    // Update stats based on completion
    const step = roadmap.steps.find(s => s.id === stepId);
    
    if (step && !step.completed) { // If marking as complete (was previously incomplete)
         setStats(prev => ({
            ...prev,
            xp: prev.xp + 100,
            completedModules: prev.completedModules + 1,
            // Simple streak logic: if it was 0, now it's 1. 
            // In a real app, check timestamps.
            streak: prev.streak === 0 ? 1 : prev.streak 
         }));
    }
  };

  const renderContent = () => {
    switch (currentView) {
      case 'assessment':
        return currentUser ? (
          <Assessment user={currentUser} onComplete={handleAssessmentComplete} />
        ) : null;
      case 'dashboard':
        return currentUser ? (
          <Dashboard 
            user={currentUser} 
            stats={stats} 
            roadmap={roadmap} 
            onNavigate={setCurrentView} 
          />
        ) : null;
      case 'roadmap':
        return roadmap ? (
          <RoadmapView roadmap={roadmap} onToggleStep={toggleRoadmapStep} />
        ) : (
           <div className="flex flex-col items-center justify-center h-full text-center">
             <p className="text-slate-400 mb-4">No roadmap generated yet.</p>
             <button onClick={() => setCurrentView('assessment')} className="text-blue-400 hover:underline">Go to Assessment</button>
           </div>
        );
      case 'games':
        // Determine topic from next incomplete step
        const nextStep = roadmap?.steps.find(s => !s.completed);
        const topic = nextStep ? nextStep.title : "General Tech Skills";
        return (
          <Games 
            topic={topic} 
            userStats={stats} 
            onUpdateStats={setStats} 
          />
        );
      case 'jobs':
        return currentUser ? (
          <Jobs user={currentUser} roadmap={roadmap} />
        ) : null;
      default:
        return <div>Not Found</div>;
    }
  };

  return (
    <Layout 
      currentUser={currentUser} 
      currentView={currentView} 
      onNavigate={setCurrentView}
      onLogout={() => {
        setCurrentUser(null);
        setCurrentView('auth');
      }}
      onOpenFeedback={() => setIsFeedbackOpen(true)}
    >
      {currentView === 'auth' ? (
        <Auth onLogin={handleLogin} />
      ) : (
        renderContent()
      )}
      
      <FeedbackModal 
        isOpen={isFeedbackOpen} 
        onClose={() => setIsFeedbackOpen(false)} 
      />
    </Layout>
  );
}

export default App;