import React from 'react';
import { Roadmap, RoadmapStep, Resource } from '../types';
import { CheckCircle2, Circle, Clock, ExternalLink, Award, DollarSign, BookOpen, Compass, Target, HelpCircle } from 'lucide-react';

interface RoadmapViewProps {
  roadmap: Roadmap;
  onToggleStep: (stepId: string) => void;
}

export const RoadmapView: React.FC<RoadmapViewProps> = ({ roadmap, onToggleStep }) => {
  return (
    <div className="animate-fade-in pb-10">
        <header className="mb-8">
            <div className="flex items-center space-x-3 mb-2">
                <h2 className="text-3xl font-bold">{roadmap.title}</h2>
                <span className="bg-blue-500/20 text-blue-300 text-xs px-2 py-1 rounded border border-blue-500/30">
                    Target NSQF Level {roadmap.targetNsqfLevel}
                </span>
                {roadmap.domain && (
                    <span className="bg-purple-500/20 text-purple-300 text-xs px-2 py-1 rounded border border-purple-500/30">
                        {roadmap.domain}
                    </span>
                )}
            </div>
            <p className="text-slate-400 max-w-3xl">{roadmap.description}</p>
        </header>

        {/* Learning Objectives & Decision Prompts Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            {roadmap.learningObjectives && roadmap.learningObjectives.length > 0 && (
                <div className="bg-slate-800/30 border border-slate-700/50 rounded-2xl p-6">
                    <div className="flex items-center space-x-2 mb-4 text-emerald-400">
                        <Target size={20} />
                        <h3 className="font-semibold text-sm uppercase tracking-wider">Learning Objectives</h3>
                    </div>
                    <ul className="space-y-3">
                        {roadmap.learningObjectives.map((obj, i) => (
                            <li key={i} className="flex items-start text-slate-300 text-sm">
                                <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-emerald-500 rounded-full shrink-0"></span>
                                {obj}
                            </li>
                        ))}
                    </ul>
                </div>
            )}
            
            {roadmap.decisionPrompts && roadmap.decisionPrompts.length > 0 && (
                <div className="bg-slate-800/30 border border-slate-700/50 rounded-2xl p-6">
                     <div className="flex items-center space-x-2 mb-4 text-amber-400">
                        <HelpCircle size={20} />
                        <h3 className="font-semibold text-sm uppercase tracking-wider">Decision Prompts</h3>
                    </div>
                     <ul className="space-y-3">
                        {roadmap.decisionPrompts.map((prompt, i) => (
                            <li key={i} className="flex items-start text-slate-300 text-sm italic">
                                <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-amber-500 rounded-full shrink-0"></span>
                                "{prompt}"
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>

        <div className="relative">
            {/* Vertical Line */}
            <div className="absolute left-6 md:left-8 top-4 bottom-0 w-0.5 bg-slate-800"></div>

            <div className="space-y-12">
                {roadmap.steps.map((step, index) => (
                    <div key={step.id} className="relative pl-20 md:pl-24 group">
                        {/* Connector Node */}
                        <button 
                            onClick={() => onToggleStep(step.id)}
                            className={`absolute left-0 top-0 w-12 h-12 md:w-16 md:h-16 rounded-full border-4 flex items-center justify-center transition-all z-10 ${
                                step.completed 
                                    ? 'bg-[#0f172a] border-green-500 text-green-500' 
                                    : 'bg-[#1e293b] border-slate-700 text-slate-500 hover:border-blue-500 hover:text-blue-400'
                            }`}
                        >
                            {step.completed ? <CheckCircle2 size={24} /> : <span className="text-xl font-bold">{index + 1}</span>}
                        </button>

                        <div className="bg-[#1e293b]/50 border border-slate-700/50 rounded-2xl p-6 hover:border-blue-500/30 transition-all">
                            <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                                <div>
                                    <h3 className={`text-xl font-bold mb-1 ${step.completed ? 'text-green-400 line-through decoration-green-500/50' : 'text-white'}`}>
                                        {step.title}
                                    </h3>
                                    <p className="text-slate-400 text-sm mb-3">{step.description}</p>
                                    <div className="flex flex-wrap gap-2">
                                        <span className="inline-flex items-center text-xs font-medium bg-slate-800 text-slate-300 px-2 py-1 rounded">
                                            <Award size={12} className="mr-1" /> NSQF L{step.nsqfLevel}
                                        </span>
                                        <span className="inline-flex items-center text-xs font-medium bg-slate-800 text-slate-300 px-2 py-1 rounded">
                                            <Clock size={12} className="mr-1" /> ~{step.estimatedHours} hrs
                                        </span>
                                    </div>
                                </div>
                                <button 
                                    onClick={() => onToggleStep(step.id)}
                                    className={`mt-4 md:mt-0 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                                        step.completed 
                                            ? 'bg-green-500/10 text-green-400' 
                                            : 'bg-blue-600 hover:bg-blue-500 text-white'
                                    }`}
                                >
                                    {step.completed ? 'Completed' : 'Mark Complete'}
                                </button>
                            </div>

                            <div className="mt-6">
                                <h4 className="text-sm font-semibold text-slate-500 uppercase tracking-wider mb-3">Recommended Resources</h4>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    {step.resources.map((res, i) => (
                                        <ResourceCard key={i} resource={res} />
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            
            <div className="pl-20 md:pl-24 pt-12 pb-20">
                <div className="flex items-center text-slate-500">
                    <div className="w-16 h-16 rounded-full border-2 border-dashed border-slate-700 flex items-center justify-center absolute left-0 bg-[#0f172a] z-10">
                        <Award size={24} />
                    </div>
                    <p className="italic">Goal Achieved! Continue to next level.</p>
                </div>
            </div>
        </div>
    </div>
  );
};

const ResourceCard: React.FC<{ resource: Resource }> = ({ resource }) => {
    return (
        <a 
            href={resource.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center p-3 rounded-xl bg-slate-900/50 border border-slate-700/50 hover:bg-slate-800 hover:border-blue-500/50 transition-all group"
        >
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center mr-3 shrink-0 ${
                resource.priority === 'high' ? 'bg-amber-500/10 text-amber-500' : 'bg-slate-800 text-slate-400'
            }`}>
                <BookOpen size={18} />
            </div>
            <div className="flex-1 overflow-hidden">
                <h5 className="text-sm font-medium text-slate-200 truncate group-hover:text-blue-400 transition-colors">
                    {resource.title}
                </h5>
                <div className="flex items-center space-x-2 mt-1">
                    <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                        resource.isPaid ? 'bg-red-500/10 text-red-400' : 'bg-green-500/10 text-green-400'
                    }`}>
                        {resource.isPaid ? 'Paid' : 'Free'}
                    </span>
                    <span className="text-xs text-slate-500 capitalize">{resource.type}</span>
                </div>
            </div>
            <ExternalLink size={14} className="text-slate-600 group-hover:text-blue-400 ml-2" />
        </a>
    )
}