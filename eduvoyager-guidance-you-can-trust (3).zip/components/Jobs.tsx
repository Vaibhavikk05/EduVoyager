import React, { useEffect, useState } from 'react';
import { generateJobs } from '../services/gemini';
import { Job, User, Roadmap } from '../types';
import { Briefcase, MapPin, DollarSign, ExternalLink, RefreshCw, Building2, Search } from 'lucide-react';

interface JobsProps {
  user: User;
  roadmap: Roadmap | null;
}

export const Jobs: React.FC<JobsProps> = ({ user, roadmap }) => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchJobs = async () => {
      setLoading(true);
      // Derive skills from roadmap titles or default to user designation
      const skills = roadmap 
        ? roadmap.steps.slice(0, 3).map(s => s.title) 
        : [user.designation, "General Skills"];
      
      const results = await generateJobs(user.designation, skills);
      setJobs(results);
      setLoading(false);
    };

    if (user) {
      fetchJobs();
    }
  }, [user, roadmap]);

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh]">
        <RefreshCw className="animate-spin text-blue-500 mb-4" size={32} />
        <p className="text-slate-400">Scanning job portals for matches...</p>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-4">
        <div>
          <h2 className="text-3xl font-bold mb-2">Career Hub</h2>
          <p className="text-slate-400">
            Jobs curated for you based on your current skills and roadmap progress.
          </p>
        </div>
        <div className="bg-slate-800 p-2 rounded-lg flex items-center text-sm text-slate-400 border border-slate-700">
           <Search size={16} className="mr-2" />
           <span>Matches found: {jobs.length}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {jobs.map((job) => (
          <div key={job.id} className="bg-[#1e293b]/50 border border-slate-700/50 rounded-2xl p-6 hover:border-blue-500/30 transition-all group relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl -mr-10 -mt-10 transition-all group-hover:bg-blue-500/10"></div>
            
            <div className="flex flex-col md:flex-row justify-between gap-6 relative z-10">
              <div className="flex-1">
                <div className="flex items-start justify-between mb-2">
                    <h3 className="text-xl font-bold text-white group-hover:text-blue-400 transition-colors">{job.title}</h3>
                    <div className="flex items-center bg-green-500/10 text-green-400 px-3 py-1 rounded-full text-xs font-bold border border-green-500/20">
                        {job.matchScore}% Match
                    </div>
                </div>
                
                <div className="flex flex-wrap items-center gap-4 text-sm text-slate-400 mb-4">
                  <div className="flex items-center">
                    <Building2 size={16} className="mr-1.5" />
                    {job.company}
                  </div>
                  <div className="flex items-center">
                    <MapPin size={16} className="mr-1.5" />
                    {job.location}
                  </div>
                  <div className="flex items-center">
                    <DollarSign size={16} className="mr-1.5" />
                    {job.salaryRange}
                  </div>
                  <div className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-xs">
                    {job.type}
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mt-4">
                  {job.skills.map((skill, i) => (
                    <span key={i} className="text-xs bg-slate-800 text-slate-300 px-2 py-1 rounded border border-slate-700/50">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex flex-col justify-center items-end gap-3 min-w-[140px]">
                <span className={`text-xs font-bold uppercase tracking-wider px-2 py-1 rounded ${
                    job.platform === 'LinkedIn' ? 'bg-[#0077b5]/10 text-[#0077b5]' : 
                    job.platform === 'Indeed' ? 'bg-[#2164f3]/10 text-[#2164f3]' : 
                    'bg-slate-700 text-slate-300'
                }`}>
                    Via {job.platform}
                </span>
                <a 
                  href={job.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center w-full bg-blue-600 hover:bg-blue-500 text-white font-medium py-2.5 px-4 rounded-xl transition-colors shadow-lg shadow-blue-900/20"
                >
                  Apply Now
                  <ExternalLink size={16} className="ml-2" />
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};