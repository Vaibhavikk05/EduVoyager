import React, { useState } from 'react';
import { User } from '../types';
import { ArrowRight, Sparkles, ShieldCheck, TrendingUp } from 'lucide-react';

interface AuthProps {
  onLogin: (user: User) => void;
}

export const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    designation: '',
    educationStage: 'discovery',
    age: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Map dropdown to designation label if needed, or keep generic
    let finalStage: User['educationStage'] = 'discovery';
    
    // Map selection to stage logic
    switch(formData.designation) {
        case 'Under 10th Grade': finalStage = 'discovery'; break;
        case 'Class 11-12': finalStage = 'direction'; break;
        case 'College / Graduate': finalStage = 'commitment'; break;
        case 'Working Professional': finalStage = 'progression'; break;
        default: finalStage = 'discovery';
    }

    onLogin({
      firstName: formData.firstName || 'Alex',
      lastName: formData.lastName || 'Doe',
      email: formData.email,
      designation: formData.designation || 'Student',
      educationStage: finalStage,
      age: parseInt(formData.age) || 15,
    });
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#0f172a] text-white">
      {/* Left Side - Hero */}
      <div className="w-full md:w-1/2 p-8 md:p-16 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-900/20 to-purple-900/20 z-0"></div>
        <div className="relative z-10">
          <div className="flex items-center space-x-2 mb-8">
            <div className="w-10 h-10 bg-gradient-to-tr from-blue-500 to-purple-500 rounded-xl flex items-center justify-center">
              <Sparkles size={20} className="text-white" />
            </div>
            <span className="text-2xl font-bold tracking-tight">EduVoyager</span>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold leading-tight mb-6">
            Guidance you can <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">trust</span>,<br/>
            at your own pace.
          </h1>
          <p className="text-lg text-slate-400 max-w-md">
            AI-guided, NSQF-aligned learning roadmaps that help you choose the right path, build real skills, and track your progress.
          </p>
        </div>

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
            <div className="bg-slate-800/50 backdrop-blur-sm p-5 rounded-2xl border border-slate-700/50">
                <ShieldCheck className="text-blue-400 mb-3" size={24} />
                <h3 className="font-semibold text-lg mb-1">NSQF Aligned</h3>
                <p className="text-sm text-slate-400">Standardized skill levels for recognized growth.</p>
            </div>
            <div className="bg-slate-800/50 backdrop-blur-sm p-5 rounded-2xl border border-slate-700/50">
                <TrendingUp className="text-purple-400 mb-3" size={24} />
                <h3 className="font-semibold text-lg mb-1">Smart Tracking</h3>
                <p className="text-sm text-slate-400">Visual progress and gamified milestones.</p>
            </div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="w-full md:w-1/2 flex items-center justify-center p-6 md:p-12 bg-[#0b1120]">
        <div className="w-full max-w-md">
            <div className="text-center mb-10">
                <h2 className="text-3xl font-bold mb-2">{isSignUp ? 'Start Your Journey' : 'Welcome Back'}</h2>
                <p className="text-slate-400">
                    {isSignUp ? 'Create an account to build your roadmap.' : 'Enter your details to access your progress.'}
                </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
                {isSignUp && (
                    <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">First Name</label>
                            <input 
                                required
                                type="text" 
                                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-white"
                                placeholder="John"
                                value={formData.firstName}
                                onChange={e => setFormData({...formData, firstName: e.target.value})}
                            />
                        </div>
                        <div className="space-y-1">
                            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Last Name</label>
                            <input 
                                required
                                type="text" 
                                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-white"
                                placeholder="Doe"
                                value={formData.lastName}
                                onChange={e => setFormData({...formData, lastName: e.target.value})}
                            />
                        </div>
                    </div>
                )}

                <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Email</label>
                    <input 
                        required
                        type="email" 
                        className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-white"
                        placeholder="you@example.com"
                        value={formData.email}
                        onChange={e => setFormData({...formData, email: e.target.value})}
                    />
                </div>

                <div className="space-y-1">
                    <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Password</label>
                    <input 
                        required
                        type="password" 
                        className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-white"
                        placeholder="••••••••"
                        value={formData.password}
                        onChange={e => setFormData({...formData, password: e.target.value})}
                    />
                </div>

                {isSignUp && (
                    <div className="grid grid-cols-3 gap-4">
                         <div className="col-span-2 space-y-1">
                            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Current Stage</label>
                            <select 
                                required
                                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-white appearance-none"
                                value={formData.designation}
                                onChange={e => setFormData({...formData, designation: e.target.value})}
                            >
                                <option value="" disabled>Select Stage...</option>
                                <option value="Under 10th Grade">Student (Under 10th) - Discovery</option>
                                <option value="Class 11-12">Student (11-12) - Direction</option>
                                <option value="College / Graduate">College / Grad - Commitment</option>
                                <option value="Working Professional">Working - Progression</option>
                            </select>
                        </div>
                         <div className="space-y-1">
                            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Age</label>
                            <input 
                                required
                                type="number" 
                                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-white"
                                placeholder="Age"
                                value={formData.age}
                                onChange={e => setFormData({...formData, age: e.target.value})}
                            />
                        </div>
                    </div>
                )}

                <button 
                    type="submit" 
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white font-bold py-4 rounded-xl transition-all shadow-lg shadow-blue-900/20 flex items-center justify-center group"
                >
                    {isSignUp ? 'Create Account' : 'Sign In'}
                    <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
                </button>
            </form>

            <div className="mt-6 text-center">
                <p className="text-slate-400">
                    {isSignUp ? 'Already have an account?' : "Don't have an account?"}
                    <button 
                        onClick={() => setIsSignUp(!isSignUp)}
                        className="ml-2 text-blue-400 hover:text-blue-300 font-semibold"
                    >
                        {isSignUp ? 'Log in' : 'Sign up'}
                    </button>
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};